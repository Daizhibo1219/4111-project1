 Genshin_database web application for COMS4111 project1.
 This application only allows users in our database to login in. For test, please try UID:45, Name:MHY.
